compiled using javac -g IDT\IDT.java from the folder containing IDT.
run using java IDT\IDT from said folder again.

needs to be done this way due to in order to accomodate java's relative pathway/package compatability for now ~ can be redone.